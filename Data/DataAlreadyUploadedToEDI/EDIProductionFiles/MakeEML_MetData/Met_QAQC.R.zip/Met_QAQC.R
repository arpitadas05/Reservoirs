###QA/QC script for FCR meteorological data Environmental Data Initiative publishing
###Script written by Bethany Bookout & Cayelan Carey
###Last modified 21 July 2019 to publish 2015-2018 met data to EDI
###Contact info: Cayelan Carey, Virginia Tech, cayelan@vt.edu

###1) Install and load packages needed
#install.packages("lubridate")
#install.packages("tidyverse")
library(lubridate)
library(tidyverse)
rm(list=ls()) #let's start with a blank slate

###2) Download the "raw" meteorological FCR datasets from GitHub and aggregate into 1 file: 
#a. Past Met data, manual downloads
RawMet_1516=read.csv('https://raw.githubusercontent.com/CareyLabVT/FCR-GLM/master/RawMetData_2015_2016.csv',header = T) #2015-2016 data
RawMet_17=read.csv('https://raw.githubusercontent.com/CareyLabVT/FCR-GLM/master/RawMetData_2017.csv',header = T) #2017 data
RawMet_18=read.csv('https://raw.githubusercontent.com/CareyLabVT/FCR-GLM/master/RawMetData_2018.csv',header = T) #2018 data
mytempdata = rbind(RawMet_1516, RawMet_17) #merges first 3 years of met data
Met_past = rbind(mytempdata, RawMet_18) #merges 2018 with data
Met_past$TIMESTAMP=with_tz(ymd_hms(Met_past$TIMESTAMP, tz="Etc/GMT+4"),"Etc/GMT+5") #formats to be same

#Note for publishing the 2015-2018 dataset, I skipped this step, but for future archiving,
  # you would need to add in the most recent data that are archived. To do so:

####Aggregate most recent met data, loaded to GitHub by Carina sensor gateway ####
Met_now=read.csv("https://raw.githubusercontent.com/CareyLabVT/SCCData/carina-data/FCRmet.csv", skip = 4, header = F) 
#loads in data from SCC_data repository for latest push
if(length(names(Met_now))>17){ #removes NR01TK_Avg column, which was downloaded on some but not all days
  Met_now$V17<-NULL #remove extra column
}
#renames and reformats dataset for easy bind
names(Met_now) = c("TIMESTAMP","RECORD","BattV","PTemp_C","PAR_Den_Avg","PAR_Tot_Tot","BP_kPa_Avg","AirTC_Avg","RH","Rain_mm_Tot","WS_ms_Avg","WindDir","SR01Up_Avg","SR01Dn_Avg","IR01UpCo_Avg","IR01DnCo_Avg","Albedo_Avg")
met_timechange=max(which(Met_now$TIMESTAMP=="2019-04-15 10:19:00")) #shows time point when met station was switched from GMT -4 to GMT -5
Met_now$TIMESTAMP<-as.POSIXct(strptime(Met_now$TIMESTAMP, "%Y-%m-%d %H:%M"), tz = "Etc/GMT+5") #get dates aligned
Met_now$TIMESTAMP[c(1:met_timechange-1)]<-with_tz(force_tz(Met_now$TIMESTAMP[c(1:met_timechange-1)],"Etc/GMT+4"), "Etc/GMT+5") #pre time change data gets assigned proper timezone then corrected to GMT -5 to match the rest of the data set

Met_now=Met_now[-c(which(is.na(Met_now$TIMESTAMP))),] #checks for NA from failed parse, and deletes from dataset
Met_now$PAR_Tot_Tot=as.numeric(Met_now$PAR_Tot_Tot) #matching str to past data
#str(Met_now); str(Met_past) #checks structure for matching of historical dataset with
# current data

Met_agg<-rbind(Met_past,Met_now) #binds past and current data from Met station
Met_agg = Met_agg[!duplicated(Met_agg$TIMESTAMP),] #takes out duplicated values by timestamp


####3) Aggregate data set for QA/QC ####
#Met= Met_agg #reset data so you don't have to load from scratch 
Met = Met_past #if you are *only* archiving past data - note! you won't do this if you are adding in new data after 2018
Met$TIMESTAMP=ymd_hms(Met$TIMESTAMP, tz="Etc/GMT+5") #formats timestamp as double check; resulted in 1 failed parse
Met = Met[year(Met$TIMESTAMP)<2019,] #all data before 2019

#order data by timestamp
Met=Met[order(Met$TIMESTAMP),]
Met$DOY=yday(Met$TIMESTAMP)

#check record for gaps
#daily record gaps by day of year
for(i in 2:nrow(Met)){ #this identifies if there are any data gaps in the long-term record, and where they are by record number
  if(Met$DOY[i]-Met$DOY[i-1]>1){
    print(c(Met$TIMESTAMP[i-1],Met$TIMESTAMP[i]))
  }
}
#sub-daily record gaps by record number
for(i in 2:length(Met$RECORD)){ #this identifies if there are any data gaps in the long-term record, and where they are by record number
   if(abs(Met$RECORD[i]-Met$RECORD[i-1])>1){
     print(c(Met$TIMESTAMP[i-1],Met$TIMESTAMP[i]))
    }
}

#EDI Column names
names(Met) = c("DateTime","Record", "CR3000_Batt_V", "CR3000Panel_temp_C", 
               "PAR_Average_umol_s_m2", "PAR_Total_mmol_m2", "BP_Average_kPa", "AirTemp_Average_C", 
               "RH_percent", "Rain_Total_mm", "WindSpeed_Average_m_s", "WindDir_degrees", "ShortwaveRadiationUp_Average_W_m2",
               "ShortwaveRadiationDown_Average_W_m2", "InfaredRadiationUp_Average_W_m2",
               "InfaredRadiationDown_Average_W_m2", "Albedo_Average_W_m2", "DOY") #finalized column names
Met$Reservoir= "FCR"#add reservoir name for EDI archiving
Met$Site=50 #add site column for EDI archiving
Met_raw=Met #Met=Met_raw; reset your data

####4) Load in maintenance txt file #### 
# the maintenance file tracks when sensors were repaired or offline due to maintenance
RemoveMet=read.table("https://raw.githubusercontent.com/CareyLabVT/SCCData/carina-data/MET_MaintenanceLog.txt", sep = ",", header = T)
#str(RemoveMet)
RemoveMet$TIMESTAMP_start=with_tz(ymd_hms(RemoveMet$TIMESTAMP_start, tz="Etc/GMT+4"),"Etc/GMT+5")#setting time zone
RemoveMet$TIMESTAMP_end=with_tz(ymd_hms(RemoveMet$TIMESTAMP_end, tz="Etc/GMT+4"),"Etc/GMT+5") #setting time zone
RemoveMet$notes=as.character(RemoveMet$notes)


####5) Create data flags for publishing ####
#create flag + notes columns for data columns c(5:17)
#set flag 2
for(i in 5:17) { #for loop to create new columns in data frame
  Met[,paste0("Flag_",colnames(Met[i]))] <- 0 #creates flag column + name of variable
  Met[,paste0("Note_",colnames(Met[i]))] <- NA #creates note column + names of variable
  Met[c(which(is.na(Met[,i]))),paste0("Flag_",colnames(Met[i]))] <-2 #puts in flag 2
  Met[c(which(is.na(Met[,i]))),paste0("Note_",colnames(Met[i]))] <- "Sample not collected" #note for flag 2
}

#Air temperature data cleaning
#create linear model between the panel temp and the air temperature sensor for 2015,
    # (lm_Panel2015) and then apply correction to air temperature dataset
MetAir_2015=Met[Met$DateTime<"2016-01-01 00:00:00",c(1,4,8)]
lm_Panel2015=lm(MetAir_2015$AirTemp_Average_C ~ MetAir_2015$CR3000Panel_temp_C)
summary(lm_Panel2015)#gives data on linear model parameters

#if Air - Panel > 3 sd(lm_Panel2015) then replace with PanelTemp predicted by lm equation rather than raw value
Met$Flag_AirTemp_Average_C=ifelse((Met$AirTemp_Average_C - (1.6278+(0.9008*Met$CR3000Panel_temp_C)))>(3*sd(lm_Panel2015$residuals)), 4, Met$Flag_AirTemp_Average_C)
Met$Note_AirTemp_Average_C=ifelse((Met$AirTemp_Average_C - (1.6278+(0.9008*Met$CR3000Panel_temp_C)))>(3*sd(lm_Panel2015$residuals)),"Substituted_value_calculated_from_Panel_Temp_and_linear_model", Met$Note_AirTemp_Average_C)
Met$AirTemp_Average_C=ifelse((Met$AirTemp_Average_C - (1.6278+(0.9008*Met$CR3000Panel_temp_C)))>(3*sd(lm_Panel2015$residuals)),(1.6278+(0.9008*Met$CR3000Panel_temp_C)), Met$AirTemp_Average_C)

#Infared radiation cleaning
#fix infrared radiation voltage reading after airtemp correction
Met$Flag_InfaredRadiationUp_Average_W_m2=ifelse(Met$InfaredRadiationUp_Average_W_m2<100,4,Met$Flag_InfaredRadiationUp_Average_W_m2)
Met$Note_InfaredRadiationUp_Average_W_m2=ifelse(Met$InfaredRadiationUp_Average_W_m2<100,"Value_corrected_from_Voltage_with_InfRadUp_equation_as_described_in_metadata",Met$Note_InfaredRadiationUp_Average_W_m2)
Met$InfaredRadiationUp_Average_W_m2=ifelse(Met$InfaredRadiationUp_Average_W_m2<100,Met$InfaredRadiationUp_Average_W_m2+5.67*10^-8*(Met$AirTemp_Average_C+273.15)^4,Met$InfaredRadiationUp_Average_W_m2)

Met$Flag_InfaredRadiationDown_Average_W_m2=ifelse(Met$InfaredRadiationDown_Average_W_m2<250,4,Met$Flag_InfaredRadiationDown_Average_W_m2)
Met$Note_InfaredRadiationDown_Average_W_m2=ifelse(Met$InfaredRadiationDown_Average_W_m2<250,"Value_corrected_from_Voltage_with_InfRadDn_equation_as_described_in_metadata",Met$Note_InfaredRadiationDown_Average_W_m2)
Met$InfaredRadiationDown_Average_W_m2=ifelse(Met$InfaredRadiationDown_Average_W_m2<250,5.67*10^-8*(Met$AirTemp_Average_C+273.15)^4,Met$InfaredRadiationDown_Average_W_m2)

#Mean correction for InfRadDown (needs to be after voltage correction)
#Using 2018 data, taking the mean and sd of values on DOY to correct to
Met_infrad=Met[year(Met$DateTime)<2018,]
Met_infrad$infradavg=ave(Met_infrad$InfaredRadiationDown_Average_W_m2, Met_infrad$DOY) #creating column with mean of infraddown by day of year
Met_infrad$infradsd=ave(Met_infrad$InfaredRadiationDown_Average_W_m2, Met_infrad$DOY, FUN = sd) #creating column with sd of infraddown by day of year
Met_infrad=unique(Met_infrad[,c(18,47,48)])

Met=merge(Met, Met_infrad, by = "DOY") #putting in columns for infrared mean and sd by DOY into main data set
Met=Met[order(Met$DateTime),] #ordering table after merging and removing unnecessary columns

Met$Flag_InfaredRadiationDown_Average_W_m2=ifelse((Met$InfaredRadiationDown_Average_W_m2-Met$infradavg)<(-3*Met$infradsd),4,Met$Flag_InfaredRadiationDown_Average_W_m2)
Met$Note_InfaredRadiationDown_Average_W_m2=ifelse((Met$InfaredRadiationDown_Average_W_m2-Met$infradavg)<(-3*Met$infradsd),"Value_corrected_from_mean_InfRadDn_before_fouling_as_described_in_metadata",Met$Note_InfaredRadiationDown_Average_W_m2)
Met$InfaredRadiationDown_Average_W_m2=ifelse((Met$InfaredRadiationDown_Average_W_m2-Met$infradavg)<(-3*Met$infradsd),Met$infradavg,Met$InfaredRadiationDown_Average_W_m2)

Met=Met[,-c(1,47,48)]

#Inf outliers, must go after corrections
Met$Flag_InfaredRadiationUp_Average_W_m2=ifelse(Met$InfaredRadiationUp_Average_W_m2<150,4,Met$Flag_InfaredRadiationUp_Average_W_m2)
Met$Note_InfaredRadiationUp_Average_W_m2=ifelse(Met$InfaredRadiationUp_Average_W_m2<150,"Outlier_set_to_NA",Met$Note_InfaredRadiationUp_Average_W_m2)
Met$InfaredRadiationUp_Average_W_m2=ifelse(Met$InfaredRadiationUp_Average_W_m2<150,NA,Met$InfaredRadiationUp_Average_W_m2)

#Remove barometric pressure outliers
Met$Flag_BP_Average_kPa=ifelse(Met$BP_Average_kPa<99,4,Met$Flag_BP_Average_kPa)
Met$Note_BP_Average_kPa=ifelse(Met$BP_Average_kPa<99,"Outlier_set_to_NA",Met$Note_BP_Average_kPa)
Met$BP_Average_kPa=ifelse(Met$BP_Average_kPa<99,NA,Met$BP_Average_kPa)

#Remove total PAR (PAR_Tot) outliers
Met$Flag_PAR_Total_mmol_m2=ifelse(Met$PAR_Total_mmol_m2>200, 4, Met$Flag_PAR_Total_mmol_m2)
Met$Note_PAR_Total_mmol_m2=ifelse(Met$PAR_Total_mmol_m2>200, "Outlier_set_to_NA", Met$Note_PAR_Total_mmol_m2)
Met$PAR_Total_mmol_m2=ifelse(Met$PAR_Total_mmol_m2>200, NA, Met$PAR_Total_mmol_m2)

#Remove shortwave radiation outliers
#first shortwave upwelling
Met$Flag_ShortwaveRadiationUp_Average_W_m2=ifelse(Met$ShortwaveRadiationUp_Average_W_m2>1600, 4, Met$Flag_ShortwaveRadiationUp_Average_W_m2)
Met$Note_ShortwaveRadiationUp_Average_W_m2=ifelse(Met$ShortwaveRadiationUp_Average_W_m2>1600, "Outlier_set_to_NA", Met$Note_ShortwaveRadiationUp_Average_W_m2)
Met$ShortwaveRadiationUp_Average_W_m2=ifelse(Met$ShortwaveRadiationUp_Average_W_m2>1600, NA, Met$ShortwaveRadiationUp_Average_W_m2)
#and then shortwave downwelling (what goes up must come down)
Met$Flag_ShortwaveRadiationDown_Average_W_m2=ifelse(Met$ShortwaveRadiationDown_Average_W_m2>300, 4, Met$Flag_ShortwaveRadiationDown_Average_W_m2)
Met$Note_ShortwaveRadiationDown_Average_W_m2=ifelse(Met$ShortwaveRadiationDown_Average_W_m2>300, "Outlier_set_to_NA", Met$Note_ShortwaveRadiationDown_Average_W_m2)
Met$ShortwaveRadiationDown_Average_W_m2=ifelse(Met$ShortwaveRadiationDown_Average_W_m2>300, NA, Met$ShortwaveRadiationDown_Average_W_m2)

#Remove albedo outliers
Met$Flag_Albedo_Average_W_m2=ifelse(Met$Albedo_Average_W_m2>1000, 4, Met$Flag_Albedo_Average_W_m2)
Met$Note_Albedo_Average_W_m2=ifelse(Met$Albedo_Average_W_m2>1000, "Outlier_set_to_NA", Met$Note_Albedo_Average_W_m2)
Met$Albedo_Average_W_m2=ifelse(Met$Albedo_Average_W_m2>1000, NA, Met$Albedo_Average_W_m2)

Met$Flag_Albedo_Average_W_m2=ifelse(is.na(Met$ShortwaveRadiationUp_Average_W_m2)|is.na(Met$ShortwaveRadiationDown_Average_W_m2), 4, Met$Flag_Albedo_Average_W_m2)
Met$Note_Albedo_Average_W_m2=ifelse(is.na(Met$ShortwaveRadiationUp_Average_W_m2)|is.na(Met$ShortwaveRadiationDown_Average_W_m2), "Set_to_NA_because_Shortwave_equals_NA", Met$Note_Albedo_Average_W_m2)
Met$Albedo_Average_W_m2=ifelse(is.na(Met$ShortwaveRadiationUp_Average_W_m2)|is.na(Met$ShortwaveRadiationDown_Average_W_m2), NA, Met$Albedo_Average_W_m2)

#set flag 3 (see metadata: this corrects for impossible outliers)
for(i in 5:17) { #for loop to create new columns in data frame
  Met[c(which(is.infinite(Met[,i]))),paste0("Flag_",colnames(Met[i]))] <-3 #puts in flag 3
  Met[c(which(is.infinite(Met[,i]))),paste0("Note_",colnames(Met[i]))] <- "Infinite_value_set_to_NA" #note for flag 3
  Met[c(which(is.infinite(Met[,i]))),i] <- NA #set infinite vals to NA
  
  if(i!=8) { #flag 3 for negative values for everything except air temp
    Met[c(which((Met[,i]<0))),paste0("Flag_",colnames(Met[i]))] <- 3
    Met[c(which((Met[,i]<0))),paste0("Note_",colnames(Met[i]))] <- "Negative_value_set_to_0"
    Met[c(which((Met[,i]<0))),i] <- 0 #replaces value with 0
  }
  if(i==9) { #flag for RH over 100
    Met[c(which((Met[,i]>100))),paste0("Flag_",colnames(Met[i]))] <- 3
    Met[c(which((Met[,i]>100))),paste0("Note_",colnames(Met[i]))] <- "Value_set_to_100"
    Met[c(which((Met[,i]>100))),i] <- 100 #replaces value with 100
  }
}

#create loop putting in maintenance flags 1 + 4 (these are flags for values removed due
    # to maintenance and also flags potentially questionable values)
for(j in 1:nrow(RemoveMet)){
  # #if statement to only write in flag 4 if there are no other flags
  if(RemoveMet$flag[j]==4){
    Met[c(which(Met[,1]>=RemoveMet[j,2] & Met[,1]<=RemoveMet[j,3]& (Met[,paste0("Flag_",colnames(Met[RemoveMet$colnumber[j]]))]==0))), paste0("Note_",colnames(Met[RemoveMet$colnumber[j]]))]=RemoveMet$notes[j]#same as above, but for notes
    Met[c(which(Met[,1]>=RemoveMet[j,2] & Met[,1]<=RemoveMet[j,3] & (Met[,paste0("Flag_",colnames(Met[RemoveMet$colnumber[j]]))]==0))), paste0("Flag_",colnames(Met[RemoveMet$colnumber[j]]))]<-RemoveMet$flag[j]#when met timestamp is between remove timestamp
    #and met column derived from remove column
    #matching time frame, inserting flag
  }
  #if flag == 1, set parameter to NA, overwrites any other flag
  
  if(RemoveMet$flag[j]==1){
    Met[c(which((Met[,1]>=RemoveMet[j,2]) & (Met[,1]<=RemoveMet[j,3]))),paste0("Flag_",colnames(Met[RemoveMet$colnumber[j]]))] <- RemoveMet$flag[j] #when met timestamp is between remove timestamp
    #and met column derived from remove column
    #matching time frame, inserting flag
    Met[Met[,1]>=RemoveMet[j,2] & Met[,1]<=RemoveMet[j,3], paste0("Note_",colnames(Met[RemoveMet$colnumber[j]]))]=RemoveMet$notes[j]#same as above, but for notes
    
    Met[Met[,1]>=RemoveMet[j,2] & Met[,1]<=RemoveMet[j,3], colnames(Met[RemoveMet$colnumber[j]])] = NA
  } #replaces value of var with NA
}


#prints table of flag frequency
for(i in 5:17) {
  print(colnames(Met[i]))
  print(table(Met[,paste0("Flag_",colnames(Met[i]))])) }

####6) Make plots to view data #####
#plots to check for any wonkiness
x11(); par(mfrow=c(2,2))
plot(Met$DateTime, Met$CR3000_Batt_V, type = 'l')
plot(Met$DateTime, Met$CR3000Panel_temp_C, type = 'l')
#PAR
plot(Met_raw$DateTime, Met_raw$PAR_Average_umol_s_m2, col="red", type='l')
plot(Met$DateTime, Met$PAR_Average_umol_s_m2, type = 'l')
plot(Met_raw$DateTime, Met_raw$PAR_Total_mmol_m2, col="red", type='l')
plot(Met$DateTime, Met$PAR_Total_mmol_m2, type = 'l')
#BP
plot(Met_raw$DateTime, Met_raw$BP_Average_kPa, col="red", type='l')
plot(Met$DateTime, Met$BP_Average_kPa, type = 'l')
#Air Temp
plot(Met_raw$DateTime, Met_raw$AirTemp_Average_C, col="red", type='l')
points(Met$DateTime, Met$AirTemp_Average_C, type = 'l')
#RH
plot(Met_raw$DateTime, Met_raw$RH_percent, col="red", type='l')
points(Met$DateTime, Met$RH_percent, type = 'l')
#Rain
plot(Met_raw$DateTime, Met_raw$Rain_Total_mm, col="red", type='h')
points(Met$DateTime, Met$Rain_Total_mm, type = 'h')
#Wind
plot(Met$DateTime, Met$WindSpeed_Average_m_s, type = 'l')
hist(Met$WindDir_degrees)
#SW Radiation
plot(Met_raw$DateTime, Met_raw$ShortwaveRadiationUp_Average_W_m2, col="red", type='l')
plot(Met$DateTime, Met$ShortwaveRadiationUp_Average_W_m2, type = 'l')
plot(Met_raw$DateTime, Met_raw$ShortwaveRadiationDown_Average_W_m2, col="red", type='l')
plot(Met$DateTime, Met$ShortwaveRadiationDown_Average_W_m2, type = 'l')
#Albedo
plot(Met_raw$DateTime, Met_raw$Albedo_Average_W_m2, col="red", type='l')
plot(Met$DateTime, Met$Albedo_Average_W_m2, type = 'l')
#InfRad
plot(Met_raw$DateTime, Met_raw$InfaredRadiationUp_Average_W_m2, col="red", type='l')
plot(Met$DateTime, Met$InfaredRadiationUp_Average_W_m2, type = 'l')
plot(Met_raw$DateTime, Met_raw$InfaredRadiationDown_Average_W_m2, col="red", type='l')
plot(Met$DateTime, Met$InfaredRadiationDown_Average_W_m2, type = 'l')

#Met unique values for notes
for (u in 20:45) {
  print(colnames(Met[u]))
  print(unique(Met[,u]))
}

###Prep RemoveMet for final file version
names(RemoveMet) = c("Station", "DateTime_start","DateTime_end", "Parameter", "ColumnNumber", "Flag", "Notes") #finalized column names
RemoveMet$Reservoir= "FCR"#add reservoir name for EDI archiving
RemoveMet$Site=50 #add site column for EDI archiving

RemoveMet=RemoveMet[,c(8:9,1:7)]

###7) Write file with final cleaned dataset! ###
Met_final=Met[,c(18:19,1:17, 20:45)] #final column order
setwd('./Data/DataAlreadyUploadedToEDI/EDIProductionFiles/MakeEML_MetData')
write.csv(Met_final, "Met_final_2015_2018.csv", row.names=F, quote=F)
write.csv(RemoveMet, "Met_Maintenance_2015_2018.csv", row.names=F, quote = F)

